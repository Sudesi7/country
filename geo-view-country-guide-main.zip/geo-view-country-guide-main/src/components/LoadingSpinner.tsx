
import React from 'react';
import { Globe, Sparkles } from 'lucide-react';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex items-center justify-center min-h-96">
      <div className="relative">
        {/* Animated background rings */}
        <div className="absolute inset-0 rounded-full">
          <div className="w-32 h-32 border-4 border-purple-200 border-solid rounded-full animate-ping opacity-75"></div>
        </div>
        <div className="absolute inset-2 rounded-full">
          <div className="w-28 h-28 border-4 border-pink-200 border-solid rounded-full animate-ping opacity-50" style={{animationDelay: '0.5s'}}></div>
        </div>
        
        {/* Main spinning globe */}
        <div className="relative w-32 h-32 bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 rounded-full flex items-center justify-center shadow-2xl">
          <Globe className="w-16 h-16 text-white animate-spin" style={{animationDuration: '3s'}} />
          
          {/* Floating sparkles */}
          <Sparkles className="absolute -top-2 -right-2 w-6 h-6 text-yellow-300 animate-bounce" />
          <Sparkles className="absolute -bottom-2 -left-2 w-4 h-4 text-blue-300 animate-bounce" style={{animationDelay: '0.5s'}} />
          <Sparkles className="absolute top-0 left-0 w-5 h-5 text-green-300 animate-bounce" style={{animationDelay: '1s'}} />
        </div>
        
        {/* Loading text */}
        <div className="mt-8 text-center">
          <p className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 bg-clip-text text-transparent animate-pulse">
            ✨ Loading countries... ✨
          </p>
          <p className="text-white/80 mt-2 font-medium">Exploring the world for you</p>
        </div>
        
        {/* Floating dots animation */}
        <div className="flex justify-center mt-4 space-x-2">
          <div className="w-3 h-3 bg-purple-400 rounded-full animate-bounce"></div>
          <div className="w-3 h-3 bg-pink-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
          <div className="w-3 h-3 bg-red-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
        </div>
      </div>
    </div>
  );
};

export default LoadingSpinner;
