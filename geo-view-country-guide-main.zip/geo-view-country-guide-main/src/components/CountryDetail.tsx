
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, MapPin, Users, Globe, Languages, DollarSign, Clock } from 'lucide-react';

interface Country {
  name: {
    common: string;
    official: string;
  };
  capital?: string[];
  region: string;
  subregion?: string;
  population: number;
  area?: number;
  flags: {
    png: string;
    svg: string;
  };
  languages?: { [key: string]: string };
  currencies?: { [key: string]: { name: string; symbol: string } };
  timezones?: string[];
  borders?: string[];
  cca3: string;
}

interface CountryDetailProps {
  country: Country;
  onBack: () => void;
}

const CountryDetail: React.FC<CountryDetailProps> = ({ country, onBack }) => {
  const languages = country.languages ? Object.values(country.languages).join(', ') : 'N/A';
  const currencies = country.currencies 
    ? Object.values(country.currencies).map(curr => `${curr.name} (${curr.symbol})`).join(', ')
    : 'N/A';

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-96 h-96 bg-gradient-to-r from-blue-400/30 to-purple-600/30 rounded-full mix-blend-multiply filter blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-gradient-to-r from-pink-400/30 to-red-600/30 rounded-full mix-blend-multiply filter blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
      </div>

      <div className="relative max-w-6xl mx-auto p-6">
        <Button 
          onClick={onBack}
          className="mb-8 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white border-0 shadow-2xl rounded-2xl px-8 py-3 text-lg font-semibold transition-all duration-300 hover:scale-105"
        >
          <ArrowLeft className="h-5 w-5 mr-3" />
          ← Back to Countries
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Flag Card */}
          <Card className="bg-white/10 backdrop-blur-lg border-0 shadow-2xl rounded-3xl overflow-hidden group hover:bg-white/15 transition-all duration-500">
            <CardContent className="p-0">
              <div className="relative h-80 lg:h-96 overflow-hidden">
                <img
                  src={country.flags.svg || country.flags.png}
                  alt={`Flag of ${country.name.common}`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent" />
                
                {/* Floating country name overlay */}
                <div className="absolute bottom-6 left-6 right-6">
                  <h2 className="text-4xl font-bold text-white drop-shadow-2xl mb-2">
                    {country.name.common}
                  </h2>
                  <p className="text-xl text-white/90 drop-shadow-lg">{country.name.official}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Details Card */}
          <Card className="bg-white/10 backdrop-blur-lg border-0 shadow-2xl rounded-3xl">
            <CardHeader className="pb-4">
              <CardTitle className="text-3xl font-bold bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent">
                Country Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 gap-6">
                <div className="flex items-center space-x-4 bg-white/10 rounded-2xl p-4 hover:bg-white/15 transition-colors duration-300">
                  <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-3 rounded-xl">
                    <MapPin className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-white">Capital</p>
                    <p className="text-purple-200 text-lg">{country.capital?.[0] || 'N/A'}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4 bg-white/10 rounded-2xl p-4 hover:bg-white/15 transition-colors duration-300">
                  <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-3 rounded-xl">
                    <Globe className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-white">Region</p>
                    <p className="text-green-200 text-lg">
                      {country.region} {country.subregion && `• ${country.subregion}`}
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-4 bg-white/10 rounded-2xl p-4 hover:bg-white/15 transition-colors duration-300">
                  <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-3 rounded-xl">
                    <Users className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-white">Population</p>
                    <p className="text-pink-200 text-lg">{country.population.toLocaleString()}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4 bg-white/10 rounded-2xl p-4 hover:bg-white/15 transition-colors duration-300">
                  <div className="bg-gradient-to-r from-orange-500 to-red-500 p-3 rounded-xl">
                    <Languages className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-white">Languages</p>
                    <p className="text-orange-200 text-lg">{languages}</p>
                  </div>
                </div>

                {country.area && (
                  <div className="flex items-center space-x-4 bg-white/10 rounded-2xl p-4 hover:bg-white/15 transition-colors duration-300">
                    <div className="bg-gradient-to-r from-teal-500 to-blue-500 p-3 rounded-xl">
                      <MapPin className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <p className="font-bold text-white">Area</p>
                      <p className="text-teal-200 text-lg">{country.area.toLocaleString()} km²</p>
                    </div>
                  </div>
                )}

                <div className="bg-white/10 rounded-2xl p-4 hover:bg-white/15 transition-colors duration-300">
                  <div className="flex items-center space-x-4 mb-3">
                    <div className="bg-gradient-to-r from-yellow-500 to-orange-500 p-3 rounded-xl">
                      <DollarSign className="h-6 w-6 text-white" />
                    </div>
                    <p className="font-bold text-white text-lg">Currencies</p>
                  </div>
                  <p className="text-yellow-200 ml-16">{currencies}</p>
                </div>

                {country.timezones && (
                  <div className="bg-white/10 rounded-2xl p-4 hover:bg-white/15 transition-colors duration-300">
                    <div className="flex items-center space-x-4 mb-3">
                      <div className="bg-gradient-to-r from-indigo-500 to-purple-500 p-3 rounded-xl">
                        <Clock className="h-6 w-6 text-white" />
                      </div>
                      <p className="font-bold text-white text-lg">Timezones</p>
                    </div>
                    <p className="text-indigo-200 ml-16">{country.timezones.join(', ')}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CountryDetail;
