
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

interface Country {
  name: {
    common: string;
    official: string;
  };
  capital?: string[];
  region: string;
  population: number;
  flags: {
    png: string;
    svg: string;
  };
  cca3: string;
}

interface CountryCardProps {
  country: Country;
  onClick: (country: Country) => void;
}

const CountryCard: React.FC<CountryCardProps> = ({ country, onClick }) => {
  return (
    <Card 
      className="cursor-pointer group relative overflow-hidden bg-white/90 backdrop-blur-sm border-0 shadow-2xl hover:shadow-3xl transition-all duration-500 hover:scale-105 hover:-translate-y-2 rounded-3xl"
      onClick={() => onClick(country)}
    >
      {/* Gradient overlay for hover effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-400/20 via-pink-400/20 to-red-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10"></div>
      
      <CardContent className="p-0 relative">
        <div className="relative h-52 overflow-hidden rounded-t-3xl">
          <img
            src={country.flags.png}
            alt={`Flag of ${country.name.common}`}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
            onError={(e) => {
              e.currentTarget.src = '/placeholder.svg';
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
          
          {/* Floating region badge */}
          <div className="absolute top-4 right-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-3 py-1 rounded-full text-sm font-semibold shadow-lg backdrop-blur-sm">
            {country.region}
          </div>
        </div>
        
        <div className="p-6 space-y-4 relative z-20">
          <h3 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent group-hover:from-purple-700 group-hover:to-pink-700 transition-all duration-300">
            {country.name.common}
          </h3>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-3">
              <span className="font-semibold text-gray-700 flex items-center">
                🏛️ <span className="ml-2">Capital:</span>
              </span>
              <span className="text-blue-600 font-medium">{country.capital?.[0] || 'N/A'}</span>
            </div>
            
            <div className="flex items-center justify-between bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-3">
              <span className="font-semibold text-gray-700 flex items-center">
                👥 <span className="ml-2">Population:</span>
              </span>
              <span className="text-green-600 font-medium">{country.population.toLocaleString()}</span>
            </div>
          </div>
          
          {/* Hover indicator */}
          <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-center">
            <span className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-full text-sm font-semibold shadow-lg">
              Click to explore ✨
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CountryCard;
