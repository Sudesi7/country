
import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Globe, Filter } from 'lucide-react';

interface FilterBarProps {
  selectedRegion: string;
  onRegionChange: (region: string) => void;
}

const FilterBar: React.FC<FilterBarProps> = ({ selectedRegion, onRegionChange }) => {
  const regions = ['All', 'Africa', 'Americas', 'Asia', 'Europe', 'Oceania'];
  const regionEmojis = {
    'All': '🌍',
    'Africa': '🦁',
    'Americas': '🌎',
    'Asia': '🏯',
    'Europe': '🏰',
    'Oceania': '🏝️'
  };

  return (
    <div className="relative group">
      <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-teal-500 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
      <div className="relative flex items-center space-x-3 bg-white/95 backdrop-blur-sm rounded-full px-6 py-3 shadow-2xl">
        <Globe className="h-5 w-5 text-blue-600 animate-spin" style={{animationDuration: '8s'}} />
        <Filter className="h-4 w-4 text-teal-600" />
        <Select value={selectedRegion} onValueChange={onRegionChange}>
          <SelectTrigger className="w-48 border-0 bg-transparent focus:ring-0 text-gray-800 font-semibold">
            <SelectValue placeholder="Filter by Region" />
          </SelectTrigger>
          <SelectContent className="bg-white/95 backdrop-blur-sm border-0 shadow-2xl rounded-2xl">
            {regions.map((region) => (
              <SelectItem key={region} value={region} className="hover:bg-gradient-to-r hover:from-purple-100 hover:to-pink-100 rounded-xl my-1 font-medium">
                <span className="flex items-center space-x-2">
                  <span>{regionEmojis[region as keyof typeof regionEmojis]}</span>
                  <span>{region}</span>
                </span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default FilterBar;
