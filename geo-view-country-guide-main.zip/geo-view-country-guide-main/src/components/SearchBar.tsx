
import React from 'react';
import { Input } from '@/components/ui/input';
import { Search, Sparkles } from 'lucide-react';

interface SearchBarProps {
  searchTerm: string;
  onSearchChange: (term: string) => void;
}

const SearchBar: React.FC<SearchBarProps> = ({ searchTerm, onSearchChange }) => {
  return (
    <div className="relative w-full max-w-md group">
      <div className="absolute inset-0 bg-gradient-to-r from-pink-500 to-violet-500 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-pulse"></div>
      <div className="relative">
        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-600 h-5 w-5 z-10" />
        <Sparkles className="absolute right-4 top-1/2 transform -translate-y-1/2 text-purple-500 h-4 w-4 animate-bounce" />
        <Input
          type="text"
          placeholder="🔍 Search for a country..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-12 pr-12 py-4 w-full border-0 rounded-full focus:ring-4 focus:ring-purple-400/50 transition-all duration-300 bg-white/95 backdrop-blur-sm shadow-2xl text-gray-800 placeholder-gray-500 font-medium text-lg"
        />
      </div>
    </div>
  );
};

export default SearchBar;
