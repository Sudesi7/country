
import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';

interface Country {
  name: {
    common: string;
    official: string;
  };
  capital?: string[];
  region: string;
  subregion?: string;
  population: number;
  area?: number;
  flags: {
    png: string;
    svg: string;
  };
  languages?: { [key: string]: string };
  currencies?: { [key: string]: { name: string; symbol: string } };
  timezones?: string[];
  borders?: string[];
  cca3: string;
}

const fetchCountries = async (): Promise<Country[]> => {
  console.log('Fetching all countries...');
  const response = await fetch('https://restcountries.com/v3.1/all?fields=name,capital,region,subregion,population,area,flags,languages,currencies,timezones,borders,cca3');
  if (!response.ok) {
    throw new Error('Failed to fetch countries');
  }
  const data = await response.json();
  console.log('Countries fetched:', data.length);
  return data;
};

const fetchCountryByName = async (name: string): Promise<Country[]> => {
  console.log('Searching for country:', name);
  const response = await fetch(`https://restcountries.com/v3.1/name/${name}?fields=name,capital,region,subregion,population,area,flags,languages,currencies,timezones,borders,cca3`);
  if (!response.ok) {
    if (response.status === 404) {
      return [];
    }
    throw new Error('Failed to search countries');
  }
  const data = await response.json();
  console.log('Search results:', data.length);
  return data;
};

const fetchCountriesByRegion = async (region: string): Promise<Country[]> => {
  console.log('Fetching countries by region:', region);
  const response = await fetch(`https://restcountries.com/v3.1/region/${region}?fields=name,capital,region,subregion,population,area,flags,languages,currencies,timezones,borders,cca3`);
  if (!response.ok) {
    throw new Error('Failed to fetch countries by region');
  }
  const data = await response.json();
  console.log('Region results:', data.length);
  return data;
};

export const useCountries = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('All');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');

  // Debounce search term
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 500);

    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Determine which query to run based on filters
  const getQueryKey = () => {
    if (debouncedSearchTerm) {
      return ['countries', 'search', debouncedSearchTerm];
    }
    if (selectedRegion !== 'All') {
      return ['countries', 'region', selectedRegion];
    }
    return ['countries', 'all'];
  };

  const getQueryFn = () => {
    if (debouncedSearchTerm) {
      return () => fetchCountryByName(debouncedSearchTerm);
    }
    if (selectedRegion !== 'All') {
      return () => fetchCountriesByRegion(selectedRegion);
    }
    return fetchCountries;
  };

  const {
    data: countries = [],
    isLoading,
    error,
    isError
  } = useQuery({
    queryKey: getQueryKey(),
    queryFn: getQueryFn(),
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000, // 10 minutes
  });

  return {
    countries,
    isLoading,
    error: isError ? error : null,
    searchTerm,
    setSearchTerm,
    selectedRegion,
    setSelectedRegion,
  };
};
