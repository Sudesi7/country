
import React, { useState } from 'react';
import CountryCard from '@/components/CountryCard';
import CountryDetail from '@/components/CountryDetail';
import SearchBar from '@/components/SearchBar';
import FilterBar from '@/components/FilterBar';
import LoadingSpinner from '@/components/LoadingSpinner';
import { useCountries } from '@/hooks/useCountries';
import { Globe, AlertCircle, Sparkles } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface Country {
  name: {
    common: string;
    official: string;
  };
  capital?: string[];
  region: string;
  subregion?: string;
  population: number;
  area?: number;
  flags: {
    png: string;
    svg: string;
  };
  languages?: { [key: string]: string };
  currencies?: { [key: string]: { name: string; symbol: string } };
  timezones?: string[];
  borders?: string[];
  cca3: string;
}

const Index = () => {
  const {
    countries,
    isLoading,
    error,
    searchTerm,
    setSearchTerm,
    selectedRegion,
    setSelectedRegion,
  } = useCountries();

  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);

  console.log('Current state:', { 
    countriesCount: countries.length, 
    isLoading, 
    error, 
    searchTerm, 
    selectedRegion 
  });

  if (selectedCountry) {
    return (
      <CountryDetail
        country={selectedCountry}
        onBack={() => setSelectedCountry(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-72 h-72 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
        <div className="absolute top-0 right-10 w-72 h-72 bg-gradient-to-r from-purple-400 to-pink-600 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-gradient-to-r from-blue-400 to-indigo-600 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse animation-delay-4000"></div>
      </div>

      {/* Header */}
      <div className="relative bg-white/10 backdrop-blur-lg shadow-2xl border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex items-center justify-center mb-8">
            <div className="relative">
              <Globe className="h-12 w-12 text-white mr-4 animate-spin" style={{animationDuration: '10s'}} />
              <Sparkles className="absolute -top-2 -right-2 h-6 w-6 text-yellow-300 animate-bounce" />
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-white via-yellow-200 to-pink-200 bg-clip-text text-transparent drop-shadow-lg">
              World Countries Explorer
            </h1>
          </div>
          
          <div className="flex flex-col md:flex-row items-center justify-between space-y-6 md:space-y-0 md:space-x-8">
            <SearchBar
              searchTerm={searchTerm}
              onSearchChange={setSearchTerm}
            />
            <FilterBar
              selectedRegion={selectedRegion}
              onRegionChange={setSelectedRegion}
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative max-w-7xl mx-auto px-4 py-10">
        {error && (
          <Alert className="mb-8 bg-red-100/90 border-red-300 backdrop-blur-sm shadow-lg">
            <AlertCircle className="h-5 w-5 text-red-600" />
            <AlertDescription className="text-red-800 font-medium">
              Error loading countries: {error instanceof Error ? error.message : 'Unknown error'}
            </AlertDescription>
          </Alert>
        )}

        {isLoading ? (
          <LoadingSpinner />
        ) : countries.length === 0 ? (
          <div className="text-center py-16">
            <div className="bg-white/20 backdrop-blur-lg rounded-3xl p-12 max-w-md mx-auto shadow-2xl">
              <Globe className="h-20 w-20 text-white mx-auto mb-6 animate-bounce" />
              <h3 className="text-2xl font-bold text-white mb-4">No countries found</h3>
              <p className="text-white/80 text-lg">
                {searchTerm ? `No results for "${searchTerm}"` : 'Try adjusting your search or filter criteria'}
              </p>
            </div>
          </div>
        ) : (
          <>
            <div className="mb-8">
              <div className="bg-white/20 backdrop-blur-lg rounded-2xl p-4 text-center max-w-md mx-auto shadow-xl">
                <p className="text-white font-semibold text-lg">
                  🌍 Showing <span className="text-yellow-300">{countries.length}</span> countries
                  {searchTerm && (
                    <span className="block text-sm mt-1 text-white/80">
                      matching "<span className="text-pink-200">{searchTerm}</span>"
                    </span>
                  )}
                  {selectedRegion !== 'All' && (
                    <span className="block text-sm mt-1 text-white/80">
                      in <span className="text-blue-200">{selectedRegion}</span>
                    </span>
                  )}
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {countries.map((country, index) => (
                <div 
                  key={country.cca3}
                  className="animate-fade-in"
                  style={{animationDelay: `${index * 0.1}s`}}
                >
                  <CountryCard
                    country={country}
                    onClick={setSelectedCountry}
                  />
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Index;
